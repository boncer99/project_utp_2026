package com.example.a2appclasif

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.min

class SimpleImageClassifier(private val context: Context) {

    data class Recognition(val label: String, val confidence: Float)

    private var interpreter: Interpreter
    private var labels: List<String>
    private var inputImageWidth: Int
    private var inputImageHeight: Int
    private var modelInputSize: Int

    init {
        // Cargar modelo
        interpreter = Interpreter(loadModelFile("converted_tflite_quantized/model.tflite"))

        // Cargar etiquetas
        labels = context.assets.open("converted_tflite_quantized/labels.txt")
            .bufferedReader().use { it.readLines() }

        // Leer tamaño de entrada
        val inputShape = interpreter.getInputTensor(0).shape() // [1, height, width, 3]
        inputImageHeight = inputShape[1]
        inputImageWidth = inputShape[2]
        val inputDataType = interpreter.getInputTensor(0).dataType()
        modelInputSize = inputImageWidth * inputImageHeight * 3
    }

    /** Carga el modelo desde assets */
    @Throws(IOException::class)
    private fun loadModelFile(filename: String): MappedByteBuffer {
        val fileDescriptor = context.assets.openFd(filename)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, fileDescriptor.startOffset, fileDescriptor.declaredLength)
    }

    /** Convierte un Bitmap a ByteBuffer */
    private fun convertBitmapToByteBuffer(bitmap: Bitmap): ByteBuffer {
        val byteBuffer = ByteBuffer.allocateDirect(modelInputSize)
        byteBuffer.order(ByteOrder.nativeOrder())
        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, inputImageWidth, inputImageHeight, true)

        val intValues = IntArray(inputImageWidth * inputImageHeight)
        scaledBitmap.getPixels(intValues, 0, scaledBitmap.width, 0, 0, scaledBitmap.width, scaledBitmap.height)

        for (pixel in intValues) {
            // Extraer valores RGB
            val r = (pixel shr 16 and 0xFF)
            val g = (pixel shr 8 and 0xFF)
            val b = (pixel and 0xFF)

            // Como es modelo quantized int8 → usamos 0–255 (no normalizar a float)
            byteBuffer.put(r.toByte())
            byteBuffer.put(g.toByte())
            byteBuffer.put(b.toByte())
        }
        return byteBuffer
    }

    /** Clasifica un bitmap y devuelve Top-3 resultados */
    fun classify(bitmap: Bitmap, topK: Int = 3): List<Recognition> {
        val byteBuffer = convertBitmapToByteBuffer(bitmap)

        // Output del modelo: [1, numLabels]
        val output = Array(1) { ByteArray(labels.size) }
        interpreter.run(byteBuffer, output)

        // Convertir de byte (-128..127) a float (0..1)
        val probabilities = output[0].map { (it.toInt() and 0xFF) / 255.0f }

        // Ordenar por confianza y devolver top-K
        return probabilities
            .mapIndexed { index, prob -> Recognition(labels[index], prob) }
            .sortedByDescending { it.confidence }
            .take(topK)
    }
}