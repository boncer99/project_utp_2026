package com.example.a2appclasif

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.a2appclasif.ui.theme.AboutActivity
import com.example.a2appclasif.ui.theme.SettingsActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val btnGallery = findViewById<Button>(R.id.btnGallery)
        val btnCamera = findViewById<Button>(R.id.btnCamera)
        val btnSettings = findViewById<Button>(R.id.btnSettings)
        val btnAbout  = findViewById<Button>(R.id.btnAbout)

        btnGallery.setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
        }

        btnCamera.setOnClickListener {
            startActivity(Intent(this, CameraActivity::class.java))
        }

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        btnAbout.setOnClickListener{
            startActivity(Intent(this, AboutActivity::class.java))
        }

    }
}
/*
MainActivity
Herencia de AppCompatActivity
•	Tu MainActivity es una actividad Android clásica que puede usar layouts XML.
onCreate
•	Es el primer método que se ejecuta cuando la actividad se abre.
•	Dentro cargas la interfaz con setContentView.
setContentView(R.layout.activity_main)
•	Le dice a Android que use el archivo XML activity_main.xml como interfaz de usuario.
findViewById<Button>(R.id.btnGallery)
•	Busca en el XML el botón con ID btnGallery y lo asigna a una variable en Kotlin.
•	Igual para btnCamera.
setOnClickListener
•	Asocia una acción a cada botón.
•	btnGallery → abre la pantalla GalleryActivity.
•	btnCamera → abre la pantalla CameraActivity.
startActivity(Intent(...))
•	Crea una intención (Intent) que le dice a Android: “cambia a esta otra pantalla”.
•	Así se navega entre actividades.
* */