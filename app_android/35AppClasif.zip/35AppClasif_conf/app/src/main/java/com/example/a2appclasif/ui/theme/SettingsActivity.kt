package com.example.a2appclasif.ui.theme

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.a2appclasif.MainActivity
import com.example.a2appclasif.R

class SettingsActivity : AppCompatActivity() {

    private lateinit var etIp: EditText
    private lateinit var etPort: EditText
    private lateinit var etEndpoint: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        etIp = findViewById(R.id.etIp)
        etPort = findViewById(R.id.etPort)
        etEndpoint = findViewById(R.id.etEndpoint)
        btnSave = findViewById(R.id.btnSave)

        // Cargar valores previos
        /*busca el valor de "ip" en ese archivo.Si existe, lo devuelve. Si no existe aún, usa el valor por defecto*/
        val prefs = getSharedPreferences("AppConfig", MODE_PRIVATE)
        etIp.setText(prefs.getString("ip", "192.168.1.81"))
        etPort.setText(prefs.getString("port", "5000"))
        etEndpoint.setText(prefs.getString("endpoint", "/diagnostico"))

        btnSave.setOnClickListener {
            val editor = prefs.edit()  //abre el editor de SharedPreferences.
            editor.putString("ip", etIp.text.toString())
            editor.putString("port", etPort.text.toString())
            editor.putString("endpoint", etEndpoint.text.toString())
            editor.apply()

            Toast.makeText(this, "Configuration saved", Toast.LENGTH_SHORT).show()

            // Regresar al MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            finish() // cerrar activity
            //Android lo guarda en un archivo XML interno del sistema, en la ruta:
        }
    }

}//class