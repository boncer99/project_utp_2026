package com.example.a2appclasif

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class GalleryActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var tvResults: TextView
    private lateinit var tvApiResponse: TextView
    private lateinit var classifier: SimpleImageClassifier //agregado para clasificar

    companion object {
        private const val PICK_IMAGE_REQUEST = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        classifier = SimpleImageClassifier(this) //clasficiador

        val btnSelectImage = findViewById<Button>(R.id.btnSelectImage)
        imageView = findViewById(R.id.imageView)
        tvResults = findViewById(R.id.tvResults)
        tvApiResponse = findViewById(R.id.tvApiResponse)

        btnSelectImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            val imageUri: Uri? = data?.data

            if (imageUri != null) {
                val inputStream = contentResolver.openInputStream(imageUri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                imageView.setImageBitmap(bitmap)

                // Clasificar imagen
                val results = classifier.classify(bitmap, 3)

                // Mostrar resultados
                val sb = StringBuilder()
                for (result in results) {
                    sb.append(result.label)
                    sb.append(": ")
                    sb.append((result.confidence * 100).toInt())
                    sb.append("%\n")
                }
                tvResults.text = sb.toString()

                // Tomar el más probable
                var estadoHoja = "Desconocido"
                if (results.isNotEmpty()) {
                    estadoHoja = results[0].label
                }
                // Consultar API y actualizar UI
                CoroutineScope(Dispatchers.IO).launch {
                    val respuestaApi = consultarApiFlask(estadoHoja)

                    withContext(Dispatchers.Main) {
                            tvApiResponse.text = respuestaApi
                    }
                }
            }//null
        }//if request
    }

    private fun consultarApiFlask(estadoHoja: String): String {
        val prefs = getSharedPreferences("AppConfig", MODE_PRIVATE)
        val ip = prefs.getString("ip", "192.168.1.81")
        val port = prefs.getString("port", "5000")
        val endpoint = prefs.getString("endpoint", "/diagnostico")

        val apiUrl = "http://$ip:$port$endpoint"
        //val apiUrl = "http://192.168.1.81:5000/diagnostico"

        val encodedParam = URLEncoder.encode(estadoHoja, "UTF-8")
        val urlWithParams = apiUrl + "?estado_hoja=" + encodedParam

        return try {
            val url = URL(urlWithParams)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 10000
            conn.readTimeout = 10000

            val responseCode = conn.responseCode
            Log.d("API_RESPONSE", "Código HTTP: $responseCode")

            if (responseCode == 200) {
                val inputStream = conn.inputStream
                val reader = BufferedReader(InputStreamReader(inputStream))
                val responseBuilder = StringBuilder()
                var line: String? = reader.readLine()
                while (line != null) {
                    responseBuilder.append(line)
                    line = reader.readLine()
                }
                reader.close()
                val responseText = responseBuilder.toString()
                Log.d("API_RESPONSE", "Respuesta: $responseText")

                // --- EXTRAER SOLO EL TEXTO DE "posible enfermedad" ---
                try {
                    val jsonObj = JSONObject(responseText)
                    jsonObj.optString("posible_enfermedad", "No detectado")
                } catch (je: Exception) {
                    Log.e("API_RESPONSE", "Error parseando JSON", je)
                    "Error leyendo respuesta"
                }
                //responseText
            } else {
                "Error en API: " + responseCode
            }
        } catch (e: Exception) {
            Log.d("API_RESPONSE", "Excepción: ${e.message}", e)
            "Error de conexión: " + e.message
        }
    }



}//class



/*
Variables de UI (imageView, tvResults)
•	Son referencias a los elementos del XML (ImageView y TextView) donde:
o	imageView mostrará la imagen seleccionada.
o	tvResults mostrará los resultados de clasificación.


 companion object con PICK_IMAGE_REQUEST
•	Constante que define un código único para identificar la acción de seleccionar imagen.
•	Se usa al recibir el resultado en onActivityResult.


setContentView(R.layout.activity_gallery)
•	Carga la interfaz definida en activity_gallery.xml.


btnSelectImage.setOnClickListener { ... }
•	Al hacer clic en el botón, crea un Intent de tipo ACTION_PICK.
•	Esto abre la galería del dispositivo para que el usuario seleccione una imagen.

startActivityForResult(intent, PICK_IMAGE_REQUEST)
•	Lanza la galería y espera un resultado (qué imagen seleccionó el usuario).
•	Ese resultado llegará a onActivityResult.

 onActivityResult(...)
•	Método que recibe el resultado de la galería.
•	Si la selección fue exitosa:
o	Obtiene la URI de la imagen.
o	La convierte en Bitmap.
o	La muestra en imageView.
o	(En el futuro) pasa la imagen al modelo de IA para obtener predicciones.
o	Escribe los resultados en tvResults.

onActivityResult solo se usa para recibir el resultado de una actividad externa lanzada con startActivityForResult.
* */