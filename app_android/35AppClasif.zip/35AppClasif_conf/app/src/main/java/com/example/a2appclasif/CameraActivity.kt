package com.example.a2appclasif


import android.Manifest
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

//Permiso → Cámara → Preview + Analyzer → Frame → Bitmap → Clasificador → Texto en pantalla.
class CameraActivity : AppCompatActivity() {

    private lateinit var classifier: SimpleImageClassifier
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var resultText: TextView
    private lateinit var apiResponseText: TextView
    private lateinit var btnSendResult: Button

    private var lastTopResult: String? = null  // Guarda el último resultado más probable

    companion object {
        private const val CAMERA_PERMISSION_REQUEST = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)

        resultText = findViewById(R.id.resultText)
        apiResponseText = findViewById(R.id.apiResponseText)
        btnSendResult = findViewById(R.id.btnSendResult)

        // Inicializar clasificador
        classifier = SimpleImageClassifier(this)
        // Executor para análisis en segundo plano
        cameraExecutor = Executors.newSingleThreadExecutor()

        // Verificar permisos
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_REQUEST
            )
        }

        // Acción del botón
        btnSendResult.setOnClickListener {
            if (lastTopResult != null) {
                val estadoHoja = lastTopResult!!
                // Lanzamos en un hilo aparte
                Thread {
                    val respuesta = consultarApiFlask(estadoHoja)
                    // Volvemos al hilo principal para actualizar la UI
                    runOnUiThread {
                        apiResponseText.text = "API: $respuesta"
                    }
                }.start()
            } else {
                Toast.makeText(this, "No result available yet", Toast.LENGTH_SHORT).show()
            }
        }
    }//onCreate

    private fun allPermissionsGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED

    //•	Es llamada automáticamente por Android cuando el usuario responde al diálogo de permisos
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults) // 👈 importante
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this, "Se requiere permiso de cámara", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun startCamera() {
        /*o	Preview → para mostrar la cámara en pantalla (PreviewView).
o	ImageAnalyzer → para procesar cada frame en segundo plano.
*/
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            // Preview
            val previewBuilder = Preview.Builder()
            val preview = previewBuilder.build()
            val previewView = findViewById<PreviewView>(R.id.viewFinder)
            preview.setSurfaceProvider(previewView.surfaceProvider)

            // Analyzer
            // 1) Crear builder
            val builder = ImageAnalysis.Builder()
            // 2) Configurar
            builder.setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            // 3) Construir objeto final
            val imageAnalyzer: ImageAnalysis = builder.build()
            // 4) Crear el Analyzer (tu clase que implementa ImageAnalysis.Analyzer)
            val analyzer = ImageAnalyzer { bitmap ->
                val results = classifier.classify(bitmap)
                runOnUiThread {
                    resultText.text = results.joinToString("\n") { rec ->
                        "${rec.label}: ${(rec.confidence * 100).toInt()}%"
                    }
                    // Guardar el más probable //PARA USAR OPENAI
                    if (results.isNotEmpty()) {    lastTopResult = results[0].label      }

                }
            }
            // 5) Asignar el analyzer
            /*Le estás diciendo al objeto imageAnalyzer (que viene de ImageAnalysis.Builder().build())
            qué función debe ejecutar cada vez que la cámara produce un frame.*/
                imageAnalyzer.setAnalyzer(cameraExecutor, analyzer)


            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalyzer
                )
            } catch (exc: Exception) {
                Log.e("CameraActivity", "Error al iniciar la cámara", exc)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    /** ---- CLASE INTERNA PARA ANALIZAR FRAMES ---- */
    //Es llamada automáticamente por CameraX cada vez que hay un frame disponible.
    private class ImageAnalyzer(private val listener: (Bitmap) -> Unit) :
        ImageAnalysis.Analyzer {

        override fun analyze(image: ImageProxy) {
            val bitmap = imageProxyToBitmap(image)
            if (bitmap != null) listener(bitmap)
            image.close()
        }

        /** Convierte ImageProxy a Bitmap en formato correcto (sin negros) */
        private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
            val planeProxy = image.planes[0].buffer
            val yuvBytes = ByteArray(planeProxy.capacity())
            planeProxy.get(yuvBytes)

            val yuvImage = YuvImage(
                yuvBytes, ImageFormat.NV21, image.width, image.height, null
            )

            val out = ByteArrayOutputStream()
            yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 100, out)
            val imageBytes = out.toByteArray()
            return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
        }
    }

    //CLASE DE CONSULTA A OPENAI
    private fun consultarApiFlask(estadoHoja: String): String {
        val prefs = getSharedPreferences("AppConfig", MODE_PRIVATE)
        val ip = prefs.getString("ip", "192.168.1.81")
        val port = prefs.getString("port", "5000")
        val endpoint = prefs.getString("endpoint", "/diagnostico")

        val apiUrl = "http://$ip:$port$endpoint"
        //val apiUrl = "http://192.168.1.81:5000/diagnostico"

        val encodedParam = URLEncoder.encode(estadoHoja, "UTF-8")
        val urlWithParams = apiUrl + "?estado_hoja=" + encodedParam

        return try {
            val url = URL(urlWithParams)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 10000
            conn.readTimeout = 10000

            val responseCode = conn.responseCode
            Log.d("API_RESPONSE", "Código HTTP: $responseCode")

            if (responseCode == 200) {
                val inputStream = conn.inputStream
                val reader = BufferedReader(InputStreamReader(inputStream))
                val responseBuilder = StringBuilder()
                var line: String? = reader.readLine()
                while (line != null) {
                    responseBuilder.append(line)
                    line = reader.readLine()
                }
                reader.close()
                val responseText = responseBuilder.toString()
                Log.d("API_RESPONSE", "Respuesta: $responseText")

                // --- EXTRAER SOLO EL TEXTO DE "posible enfermedad" ---
                try {
                    val jsonObj = JSONObject(responseText)
                    jsonObj.optString("posible_enfermedad", "No detectado")
                } catch (je: Exception) {
                    Log.e("API_RESPONSE", "Error parseando JSON", je)
                    "Error leyendo respuesta"
                }
                //responseText
            } else {
                "Error en API: " + responseCode
            }
        } catch (e: Exception) {
            Log.d("API_RESPONSE", "Excepción: ${e.message}", e)
            "Error de conexión: " + e.message
        }
    }



}
